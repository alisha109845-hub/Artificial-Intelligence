#for in loop

#Example 1
#iterating over a list
print("List Iteration")
I=["geeks","for","geeks"]
for i in I:
    print(i)
#Example 2
#Iterating over a tuple(immutable)
print("\n Tuple Iteration")
t=("geeks","for","geeks")
for i in t:
    print(i)
#Example 3
#Iterating over a String
print("\nString Iteration")
s="Geeks"
for i in s:
    print(i)
#Iterating by index
list=["geeks","for","geeks"]
for index in range(len(list)):
    print (list [index])
