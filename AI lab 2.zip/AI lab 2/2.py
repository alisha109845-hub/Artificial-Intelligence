#single statement while block
count=0
while(count==0):
    print("Hello Geek")