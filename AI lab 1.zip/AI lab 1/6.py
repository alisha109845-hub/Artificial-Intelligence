#lists
my_list1=[5,12,13,14]
print(my_list1)
my_list2=['red','blue','black','white']
print(my_list2)
my_list3=['red',12,112.12]
print(my_list3)

#list indices
my_list4=[]
print(my_list4)

color_list=["RED","BLUE","GREEN","BLACK"]
print(color_list[0])
print(color_list[0],color_list[3])
#print(color_list[4]) error

#list slices
print(color_list[1:2])
print(color_list[1:-2])
print(color_list[:3])
print(color_list[:])

