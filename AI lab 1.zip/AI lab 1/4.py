#special characters in strings
print("The is a backslash (\\) mark.")
print("This is tab \t key")
print("These are \' single qoutes\' ")
print("These are \"double qoutes\" ")
print("This is a new line\n new line")
