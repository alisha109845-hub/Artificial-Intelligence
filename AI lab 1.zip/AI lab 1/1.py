#Comments in python
x=1
#The initial value of x is 1.
if x>0:
    print("These are two comments") #print a string



#Multiple statements on a single line
print("statement1")
print("statement2")
#write 2 statements in following way:
print("statement3"); print("statement4")

#identation
x=1
if x>0:
    print("This statement has a single space identation")



