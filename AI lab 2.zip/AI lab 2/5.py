#LOOP CONTROL STATEMENTS
#Break Statement:
for letter in 'geeksforgeeks':
    if letter=='e' or letter=='s':
        break
    print ('Current Letter:',letter)